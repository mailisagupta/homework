﻿

namespace VendLib
{
    public class CoinDisplayData
    {
        public string CoinDenomination {get;set;}
        public int NumberOfCoins { get; set; }
   
        public decimal DollarValueOfCoin { get; set; }
    }
}
