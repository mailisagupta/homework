﻿
using System.Windows.Controls;


namespace VendingMachine.Views
{
    /// <summary>
    /// Interaction logic for CanRackView.xaml
    /// </summary>
    public partial class CanRackView : UserControl
    {
        //CanRackViewModel _CanRackViewModel = new CanRackViewModel();
        public CanRackView()
        {
            InitializeComponent();
            //DataContext = _CanRackViewModel;
        }
    }
}
