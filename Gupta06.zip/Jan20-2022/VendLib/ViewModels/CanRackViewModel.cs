﻿
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace VendLib
{
    public class CanRackViewModel : INotifyPropertyChanged
    {
        CanRack _c = new CanRack();

        public ObservableCollection<string> Cans { get; set; } = new();

        private string _canDetailInfo;

        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        public string CanDetailInfo
        {
            get { return _canDetailInfo; }
            set { _canDetailInfo = value;
                InvokePropertyChanged();
            }
        }

        public DelegateCommand<string> CanDetailCommand { get; }

       

        public void InvokePropertyChanged([CallerMemberName] string propertyname = null  )
        {
            PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
        }

        public CanRackViewModel()
        {
            Cans = StringValueOfCanInCanRack(_c);
            CanDetailCommand = new DelegateCommand<string>((f)=> CanDetailInfo = $"Can Flavor: {f}");

        }

        private ObservableCollection<string> StringValueOfCanInCanRack(CanRack canRack)
        { 
            ObservableCollection<string> a = new ObservableCollection<string>();
            foreach(Flavor f in FlavorOps.AllFlavors)
            {
                for (int i = 0; i < canRack[f]; i++)
                {
                    a.Add(f.ToString());
                }
            }
            return a;
        }
    }
}
