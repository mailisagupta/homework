﻿namespace VendLib
{
     public record Can(Flavor contents);
}
