﻿/// Assignment 01
/// Author: Gupta, Mailisa mailisa
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VendingMachine
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// Assignment 01
    /// Author: Gupta, Mailisa
    public partial class MainWindow : Window
    {
        ///int _Total=0;
        int _countCocaCola = 0;
        int _countGingerale = 0;
        int _countDew = 0;
        bool _tracker1 = false;
        double money = 0.00;
        double balance = 0.00;


        public MainWindow()
        {
            InitializeComponent();
           
        }

        

        private void OnImageButtonClickCocaCola(object sender, RoutedEventArgs e)
        {
           
                if (_tracker1 == true)
                {
                
                if (money < 0.50)
                    {
                        MessageBox.Show("Insufficient Funds!!");
                    }
                    else
                    {
                    _countCocaCola++;
                    if (_countCocaCola > 3)
                    {
                        MessageBox.Show("You cannot select more than 3 CocaCola");
                    }
                    else
                    {
                        money = money - (0.50);
                        money = Math.Round((Double)money, 2);
                        DisplayBalance.Text = string.Concat("$", (money.ToString()));
                        Display.Text = "Enjoy CocaCola!! Select another item to continue shopping or click on Finish Transaction to collect your Balance!";
                        //MessageBox.Show("Select another item to continue shopping or click on Finish Transaction to collect your Balance!");

                    } ///_Total = _Total + _countCocaCola

                }
                   
                }
                else
                { MessageBox.Show("Insufficient Funds!!"); 
            }
           

        }

        private void OnImageButtonClickDew(object sender, RoutedEventArgs e)
        {
           
                if (_tracker1 == true)
                {
                    if (money < 0.40)
                    {
                        MessageBox.Show("Insufficient Funds!!");
                    }
                    else
                    {
                        _countDew++;
                    if (_countDew > 3)
                    {
                        MessageBox.Show("You cannot select more than 3 Dew");
                    }
                    else
                    {
                        ///_Total = _Total + _countDew;
                        money = money - (0.40 );
                        money = Math.Round((Double)money, 2);
                        DisplayBalance.Text = string.Concat("$", (money.ToString()));
                        Display.Text = "Enjoy Mountain Dew!! Select another item to continue shopping or click on Finish Transaction to collect your Balance!";
                        ///MessageBox.Show("Select another item to continue shopping or click on Finish Transaction to collect your Balance!");

                    }

                }
                }
                else
                { 
            MessageBox.Show("Insufficient Funds!!"); 
                 }
            
            
        }

        private void OnImageButtonClickGingerale(object sender, RoutedEventArgs e)
        {

           if (_tracker1 == true)
           {
             if (money < 0.30)
              {
               MessageBox.Show("Insufficient Funds!!");
               }
             else
             {
             _countGingerale++;
                    if (_countGingerale > 3)
                    {
                        MessageBox.Show("You cannot select more than 3 Gingerale");
                    }
                    ///_Total = _Total + _countGingerale;
                    else
                    {
                        money = money - (0.30);
                        money = Math.Round((Double)money, 2);
                        DisplayBalance.Text = string.Concat("$", (money.ToString()));
                        Display.Text = "Enjoy Gingerale!! Select another item to continue shopping or click on Finish Transaction to collect your Balance!";
                        ///MessageBox.Show("Select another item to continue shopping or click on Finish Transaction to collect your Balance!");

                    }
                   
              }
           }
           else
           { MessageBox.Show("Insufficient Funds!!"); 
            }
           

        }


        private void OnButtonClickBalanceHere(object sender, RoutedEventArgs e)
        {
           /// MessageBox.Show("Your balance is, " + money.ToString() + "cents");

            Display.Text = string.Concat("Collect your balance: ", "$", (money.ToString()));
            money = 0.00;
            DisplayBalance.Text = string.Concat("$", (money.ToString()));
        }

        private void OnButtonClickNickel(object sender, RoutedEventArgs e)
        {
            _tracker1 = true;
            money = money + 0.05;
            money = Math.Round((Double)money, 2);
            balance = money;
            DisplayBalance.Text = string.Concat("$", (money.ToString()));
            Display.Text = string.Concat("You have entered ","$", (money.ToString()));
        }

        private void OnButtonClickDime(object sender, RoutedEventArgs e)
        {
            _tracker1 = true;
            money = money + 0.10;
            money = Math.Round((Double)money, 2);
            balance = money;
            DisplayBalance.Text = string.Concat("$", (money.ToString()));
            Display.Text = string.Concat("You have entered ", "$", (money.ToString()));
        }

        private void OnButtonClickHalfDollar(object sender, RoutedEventArgs e)
        {
            _tracker1 = true;
            money = money + 0.50;
            money = Math.Round((Double)money, 2);
            balance = money;
            DisplayBalance.Text = string.Concat("$", (money.ToString()));
            Display.Text = string.Concat("You have entered ", "$", (money.ToString()));
        }

        private void OnButtonClickQuarter(object sender, RoutedEventArgs e)
        {
            _tracker1 = true;
            money = money + 0.25;
            money = Math.Round((Double)money, 2);
            balance = money;
            ///MessageBox.Show("You have entered, " + money.ToString() + "cents");
            DisplayBalance.Text = string.Concat("$", (money.ToString()));
            Display.Text = string.Concat("You have entered ", "$", (money.ToString()));
        }

        private void Button1(object sender, RoutedEventArgs e)
        {

        }

        private void Button2(object sender, RoutedEventArgs e)
        {

        }
        private void Button3(object sender, RoutedEventArgs e)
        {

        }
    }
}
