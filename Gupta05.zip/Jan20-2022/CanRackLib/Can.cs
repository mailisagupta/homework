﻿namespace CanRackLib
{
     public record Can(Flavor contents);
}
