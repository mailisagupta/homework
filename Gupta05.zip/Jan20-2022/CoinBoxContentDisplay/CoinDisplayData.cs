﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoinBoxContentDisplay
{
    public class CoinDisplayData
    {
        public string CoinDenomination {get;set;}
        public int NumberOfCoins { get; set; }
   
        public decimal DollarValueOfCoin { get; set; }
    }
}
